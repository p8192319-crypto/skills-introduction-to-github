import { useState, useEffect, useRef, useCallback } from 'react';

interface Planet {
  name: string;
  nameRu: string;
  radius: number; // km
  distance: number; // AU
  orbitalPeriod: number; // Earth days
  color: string;
  displayRadius: number; // for visualization
  orbitRadius: number; // for visualization
  description: string;
}

const planets: Planet[] = [
  {
    name: 'Mercury',
    nameRu: 'Меркурий',
    radius: 2439.7,
    distance: 0.39,
    orbitalPeriod: 88,
    color: '#b5b5b5',
    displayRadius: 4,
    orbitRadius: 60,
    description: 'Самая маленькая и ближайшая к Солнцу планета. Поверхность покрыта кратерами.'
  },
  {
    name: 'Venus',
    nameRu: 'Венера',
    radius: 6051.8,
    distance: 0.72,
    orbitalPeriod: 225,
    color: '#e8cda0',
    displayRadius: 7,
    orbitRadius: 95,
    description: 'Вторая планета от Солнца. Самая горячая планета из-за парникового эффекта.'
  },
  {
    name: 'Earth',
    nameRu: 'Земля',
    radius: 6371,
    distance: 1.0,
    orbitalPeriod: 365.25,
    color: '#4b9cd3',
    displayRadius: 7,
    orbitRadius: 130,
    description: 'Наш дом. Единственная известная планета с жизнью. Имеет один спутник — Луну.'
  },
  {
    name: 'Mars',
    nameRu: 'Марс',
    radius: 3389.5,
    distance: 1.52,
    orbitalPeriod: 687,
    color: '#c1440e',
    displayRadius: 5,
    orbitRadius: 170,
    description: 'Красная планета. Имеет самый большой вулкан в Солнечной системе — Олимп.'
  },
  {
    name: 'Jupiter',
    nameRu: 'Юпитер',
    radius: 69911,
    distance: 5.2,
    orbitalPeriod: 4333,
    color: '#c88b3a',
    displayRadius: 16,
    orbitRadius: 230,
    description: 'Самая большая планета. Газовый гигант с Большим Красным Пятном — гигантским штормом.'
  },
  {
    name: 'Saturn',
    nameRu: 'Сатурн',
    radius: 58232,
    distance: 9.58,
    orbitalPeriod: 10759,
    color: '#e8d5a3',
    displayRadius: 14,
    orbitRadius: 290,
    description: 'Известен своими великолепными кольцами из льда и камней. Второй по размеру.'
  },
  {
    name: 'Uranus',
    nameRu: 'Уран',
    radius: 25362,
    distance: 19.22,
    orbitalPeriod: 30687,
    color: '#7ec8e3',
    displayRadius: 10,
    orbitRadius: 345,
    description: 'Ледяной гигант, вращающийся «на боку». Имеет 27 известных спутников.'
  },
  {
    name: 'Neptune',
    nameRu: 'Нептун',
    radius: 24622,
    distance: 30.05,
    orbitalPeriod: 60190,
    color: '#4b70dd',
    displayRadius: 10,
    orbitRadius: 395,
    description: 'Самая далёкая планета. Самые сильные ветры в Солнечной системе — до 2100 км/ч.'
  }
];

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [selectedPlanet, setSelectedPlanet] = useState<Planet | null>(null);
  const [hoveredPlanet, setHoveredPlanet] = useState<string | null>(null);
  const timeRef = useRef(0);
  const lastTimeRef = useRef(0);
  const planetPositionsRef = useRef<{ planet: Planet; x: number; y: number }[]>([]);

  const drawSolarSystem = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const centerX = width / 2;
    const centerY = height / 2;

    // Clear canvas
    ctx.fillStyle = '#0a0a1a';
    ctx.fillRect(0, 0, width, height);

    // Draw stars
    const starSeed = 42;
    for (let i = 0; i < 200; i++) {
      const x = ((starSeed * (i + 1) * 7919) % width);
      const y = ((starSeed * (i + 1) * 6271) % height);
      const size = ((i * 3571) % 3) * 0.5 + 0.5;
      const opacity = ((i * 2347) % 100) / 100 * 0.5 + 0.3;
      ctx.beginPath();
      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
      ctx.fill();
    }

    // Draw orbits
    planets.forEach((planet) => {
      ctx.beginPath();
      ctx.arc(centerX, centerY, planet.orbitRadius, 0, Math.PI * 2);
      ctx.strokeStyle = hoveredPlanet === planet.name ? 'rgba(255, 255, 255, 0.3)' : 'rgba(255, 255, 255, 0.1)';
      ctx.lineWidth = hoveredPlanet === planet.name ? 1.5 : 0.5;
      ctx.stroke();
    });

    // Draw Sun
    const sunGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, 35);
    sunGradient.addColorStop(0, '#fff7e6');
    sunGradient.addColorStop(0.3, '#ffdd00');
    sunGradient.addColorStop(0.7, '#ff9900');
    sunGradient.addColorStop(1, '#ff6600');
    ctx.beginPath();
    ctx.arc(centerX, centerY, 30, 0, Math.PI * 2);
    ctx.fillStyle = sunGradient;
    ctx.fill();

    // Sun glow
    const glowGradient = ctx.createRadialGradient(centerX, centerY, 25, centerX, centerY, 60);
    glowGradient.addColorStop(0, 'rgba(255, 200, 0, 0.3)');
    glowGradient.addColorStop(1, 'rgba(255, 200, 0, 0)');
    ctx.beginPath();
    ctx.arc(centerX, centerY, 60, 0, Math.PI * 2);
    ctx.fillStyle = glowGradient;
    ctx.fill();

    // Draw planets
    const positions: { planet: Planet; x: number; y: number }[] = [];
    
    planets.forEach((planet) => {
      // Calculate planet position based on time and orbital period
      const angularSpeed = (2 * Math.PI) / (planet.orbitalPeriod * 0.01);
      const angle = timeRef.current * angularSpeed;
      
      const x = centerX + Math.cos(angle) * planet.orbitRadius;
      const y = centerY + Math.sin(angle) * planet.orbitRadius;
      
      positions.push({ planet, x, y });

      // Planet glow
      const planetGlow = ctx.createRadialGradient(x, y, 0, x, y, planet.displayRadius * 2);
      planetGlow.addColorStop(0, planet.color + '40');
      planetGlow.addColorStop(1, 'transparent');
      ctx.beginPath();
      ctx.arc(x, y, planet.displayRadius * 2, 0, Math.PI * 2);
      ctx.fillStyle = planetGlow;
      ctx.fill();

      // Planet body
      const planetGradient = ctx.createRadialGradient(
        x - planet.displayRadius * 0.3, y - planet.displayRadius * 0.3, 0,
        x, y, planet.displayRadius
      );
      planetGradient.addColorStop(0, lightenColor(planet.color, 40));
      planetGradient.addColorStop(1, planet.color);
      
      ctx.beginPath();
      ctx.arc(x, y, planet.displayRadius, 0, Math.PI * 2);
      ctx.fillStyle = planetGradient;
      ctx.fill();

      // Saturn rings
      if (planet.name === 'Saturn') {
        ctx.beginPath();
        ctx.ellipse(x, y, planet.displayRadius * 2, planet.displayRadius * 0.5, -0.3, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(232, 213, 163, 0.6)';
        ctx.lineWidth = 2.5;
        ctx.stroke();
      }

      // Planet name label
      if (hoveredPlanet === planet.name || selectedPlanet?.name === planet.name) {
        ctx.font = '12px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(planet.nameRu, x, y - planet.displayRadius - 8);
      }
    });

    planetPositionsRef.current = positions;
  }, [hoveredPlanet, selectedPlanet]);

  const animate = useCallback((timestamp: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (lastTimeRef.current === 0) {
      lastTimeRef.current = timestamp;
    }

    if (isPlaying) {
      const deltaTime = (timestamp - lastTimeRef.current) * speed;
      timeRef.current += deltaTime * 0.001;
    }
    
    lastTimeRef.current = timestamp;

    drawSolarSystem(ctx, canvas.width, canvas.height);
    animationRef.current = requestAnimationFrame(animate);
  }, [isPlaying, speed, drawSolarSystem]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      const container = canvas.parentElement;
      if (container) {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    animationRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationRef.current);
    };
  }, [animate]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    let clickedPlanet: Planet | null = null;

    planetPositionsRef.current.forEach(({ planet, x: px, y: py }) => {
      const dist = Math.sqrt((x - px) ** 2 + (y - py) ** 2);
      if (dist <= planet.displayRadius + 5) {
        clickedPlanet = planet;
      }
    });

    setSelectedPlanet(clickedPlanet);
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    let found = false;
    planetPositionsRef.current.forEach(({ planet, x: px, y: py }) => {
      const dist = Math.sqrt((x - px) ** 2 + (y - py) ** 2);
      if (dist <= planet.displayRadius + 5) {
        setHoveredPlanet(planet.name);
        canvas.style.cursor = 'pointer';
        found = true;
      }
    });

    if (!found) {
      setHoveredPlanet(null);
      canvas.style.cursor = 'default';
    }
  };

  const formatOrbitalPeriod = (days: number): string => {
    if (days < 365) {
      return `${days} дней`;
    }
    const years = (days / 365.25).toFixed(1);
    return `${years} лет (${days.toLocaleString()} дней)`;
  };

  return (
    <div className="w-full h-screen bg-[#0a0a1a] flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex-shrink-0 px-4 py-3 bg-gradient-to-r from-[#0d1b2a] to-[#1b2838] border-b border-white/10">
        <h1 className="text-xl md:text-2xl font-bold text-white text-center">
          🌞 Интерактивная Солнечная Система
        </h1>
        <p className="text-xs md:text-sm text-gray-400 text-center mt-1">
          Нажмите на планету для получения информации
        </p>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col md:flex-row min-h-0">
        {/* Canvas Area */}
        <div className="flex-1 relative min-h-0">
          <canvas
            ref={canvasRef}
            className="w-full h-full"
            onClick={handleCanvasClick}
            onMouseMove={handleCanvasMouseMove}
          />
        </div>

        {/* Info Panel */}
        {selectedPlanet && (
          <div className="flex-shrink-0 md:w-80 bg-[#0d1b2a]/95 backdrop-blur-sm border-t md:border-t-0 md:border-l border-white/10 p-4 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white">{selectedPlanet.nameRu}</h2>
              <button
                onClick={() => setSelectedPlanet(null)}
                className="text-gray-400 hover:text-white transition-colors text-xl"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-3">
              <div className="bg-white/5 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className="w-6 h-6 rounded-full"
                    style={{ backgroundColor: selectedPlanet.color }}
                  />
                  <span className="text-gray-300 text-sm">{selectedPlanet.name}</span>
                </div>
                <p className="text-gray-400 text-sm">{selectedPlanet.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-white/5 rounded-lg p-3">
                  <div className="text-xs text-gray-500 uppercase tracking-wider">Радиус</div>
                  <div className="text-white font-semibold mt-1">
                    {selectedPlanet.radius.toLocaleString()} км
                  </div>
                </div>
                <div className="bg-white/5 rounded-lg p-3">
                  <div className="text-xs text-gray-500 uppercase tracking-wider">Расстояние</div>
                  <div className="text-white font-semibold mt-1">
                    {selectedPlanet.distance} а.е.
                  </div>
                </div>
                <div className="bg-white/5 rounded-lg p-3 col-span-2">
                  <div className="text-xs text-gray-500 uppercase tracking-wider">Орбитальный период</div>
                  <div className="text-white font-semibold mt-1">
                    {formatOrbitalPeriod(selectedPlanet.orbitalPeriod)}
                  </div>
                </div>
              </div>

              {/* Size comparison */}
              <div className="bg-white/5 rounded-lg p-3">
                <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">
                  Сравнение размеров (относительно Земли)
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className="rounded-full bg-blue-500"
                    style={{
                      width: `${Math.max(8, (selectedPlanet.radius / 6371) * 20)}px`,
                      height: `${Math.max(8, (selectedPlanet.radius / 6371) * 20)}px`
                    }}
                  />
                  <span className="text-gray-300 text-sm">
                    {(selectedPlanet.radius / 6371).toFixed(2)}× Земли
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex-shrink-0 px-4 py-3 bg-gradient-to-r from-[#0d1b2a] to-[#1b2838] border-t border-white/10">
        <div className="flex items-center justify-center gap-4 flex-wrap">
          {/* Play/Pause */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-all duration-200 border border-white/10"
          >
            {isPlaying ? (
              <>
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <rect x="6" y="4" width="4" height="16" />
                  <rect x="14" y="4" width="4" height="16" />
                </svg>
                <span className="text-sm">Пауза</span>
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <polygon points="5,3 19,12 5,21" />
                </svg>
                <span className="text-sm">Воспроизвести</span>
              </>
            )}
          </button>

          {/* Speed Control */}
          <div className="flex items-center gap-2">
            <span className="text-gray-400 text-sm">Скорость:</span>
            <div className="flex gap-1">
              {[0.25, 0.5, 1, 2, 5, 10].map((s) => (
                <button
                  key={s}
                  onClick={() => setSpeed(s)}
                  className={`px-2 py-1 rounded text-xs font-medium transition-all duration-200 ${
                    speed === s
                      ? 'bg-blue-600 text-white'
                      : 'bg-white/10 text-gray-300 hover:bg-white/20'
                  }`}
                >
                  {s}×
                </button>
              ))}
            </div>
          </div>

          {/* Reset */}
          <button
            onClick={() => {
              timeRef.current = 0;
              setSelectedPlanet(null);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-all duration-200 border border-white/10"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            <span className="text-sm">Сброс</span>
          </button>
        </div>
      </div>
    </div>
  );
}

function lightenColor(color: string, percent: number): string {
  const num = parseInt(color.replace('#', ''), 16);
  const amt = Math.round(2.55 * percent);
  const R = Math.min(255, (num >> 16) + amt);
  const G = Math.min(255, ((num >> 8) & 0x00FF) + amt);
  const B = Math.min(255, (num & 0x0000FF) + amt);
  return `#${(1 << 24 | R << 16 | G << 8 | B).toString(16).slice(1)}`;
}

export default App;
